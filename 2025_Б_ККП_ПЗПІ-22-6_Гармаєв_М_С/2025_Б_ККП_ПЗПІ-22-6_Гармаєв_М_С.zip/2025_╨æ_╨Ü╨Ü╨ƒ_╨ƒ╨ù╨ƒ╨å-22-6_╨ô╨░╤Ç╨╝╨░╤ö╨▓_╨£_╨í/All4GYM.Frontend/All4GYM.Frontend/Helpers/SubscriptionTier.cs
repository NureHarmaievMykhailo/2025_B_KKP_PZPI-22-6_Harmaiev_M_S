namespace All4GYM.Frontend.Helpers
{
    public enum SubscriptionTier
    {
        Basic = 0,
        Pro = 1,
        Premium = 2
    }
}