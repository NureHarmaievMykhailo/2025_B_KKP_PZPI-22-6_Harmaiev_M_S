using Microsoft.AspNetCore.Mvc.RazorPages;

namespace All4GYM.Frontend.Pages;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}