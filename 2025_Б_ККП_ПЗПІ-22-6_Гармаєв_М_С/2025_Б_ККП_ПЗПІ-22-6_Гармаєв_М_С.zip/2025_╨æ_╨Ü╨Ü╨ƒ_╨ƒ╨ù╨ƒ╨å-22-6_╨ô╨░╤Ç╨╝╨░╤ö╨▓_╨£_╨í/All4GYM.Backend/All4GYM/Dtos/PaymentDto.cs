namespace All4GYM.Dtos;

public class PaymentDto
{
    public string ClientSecret { get; set; } = null!;
}