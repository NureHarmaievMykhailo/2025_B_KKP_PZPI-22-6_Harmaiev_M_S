namespace All4GYM.Dtos;

public class CreateSubscriptionPaymentDto
{
    public string Tier { get; set; } = "basic";
}
