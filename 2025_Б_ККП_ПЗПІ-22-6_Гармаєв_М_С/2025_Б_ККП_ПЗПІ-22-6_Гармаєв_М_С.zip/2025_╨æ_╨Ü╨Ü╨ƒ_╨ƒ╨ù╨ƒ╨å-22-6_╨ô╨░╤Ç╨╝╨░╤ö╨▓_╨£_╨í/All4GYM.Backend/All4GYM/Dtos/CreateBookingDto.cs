namespace All4GYM.Dtos;

public class CreateBookingDto
{
    public int SessionId { get; set; }
}