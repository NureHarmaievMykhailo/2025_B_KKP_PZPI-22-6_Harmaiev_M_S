namespace All4GYM.Dtos;

public class OrderProductRequestDto
{
    public int ProductId { get; set; }
    public int Quantity { get; set; }
}