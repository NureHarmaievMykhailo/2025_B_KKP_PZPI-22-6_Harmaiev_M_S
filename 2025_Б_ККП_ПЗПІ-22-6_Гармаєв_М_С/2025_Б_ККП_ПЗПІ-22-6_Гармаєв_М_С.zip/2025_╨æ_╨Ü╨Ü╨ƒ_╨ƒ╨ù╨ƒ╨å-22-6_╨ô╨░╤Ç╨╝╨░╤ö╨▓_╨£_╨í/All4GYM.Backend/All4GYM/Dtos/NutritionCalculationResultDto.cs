namespace All4GYM.Dtos;

public class NutritionCalculationResultDto
{
    public float Calories { get; set; }
    public float ProteinGrams { get; set; }
    public float FatGrams { get; set; }
    public float CarbsGrams { get; set; }
}
