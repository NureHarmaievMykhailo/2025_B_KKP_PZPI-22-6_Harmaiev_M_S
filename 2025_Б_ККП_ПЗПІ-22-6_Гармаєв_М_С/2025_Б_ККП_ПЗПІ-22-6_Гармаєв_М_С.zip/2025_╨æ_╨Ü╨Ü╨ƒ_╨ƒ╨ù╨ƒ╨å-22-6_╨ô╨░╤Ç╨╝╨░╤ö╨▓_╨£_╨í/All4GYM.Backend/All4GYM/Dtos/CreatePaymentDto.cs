namespace All4GYM.Dtos;

public class CreatePaymentDto
{
    public int OrderId { get; set; }
}