namespace All4GYM.Dtos;

public class CreateTrainingProgramDto
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
}