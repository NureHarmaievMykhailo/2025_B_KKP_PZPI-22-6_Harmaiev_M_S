namespace All4GYM.Models;

public enum SubscriptionTier
{
    Basic = 0,
    Pro = 1,
    Premium = 2
}