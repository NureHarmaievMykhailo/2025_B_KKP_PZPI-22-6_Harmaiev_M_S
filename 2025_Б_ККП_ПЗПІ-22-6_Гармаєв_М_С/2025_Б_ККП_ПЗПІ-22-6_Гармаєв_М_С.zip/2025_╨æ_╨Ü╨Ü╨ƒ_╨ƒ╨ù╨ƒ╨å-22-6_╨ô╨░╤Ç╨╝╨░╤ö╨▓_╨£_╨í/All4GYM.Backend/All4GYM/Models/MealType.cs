namespace All4GYM.Models;

public enum MealType
{
    Breakfast,
    Lunch,
    Dinner,
    Snack
}
